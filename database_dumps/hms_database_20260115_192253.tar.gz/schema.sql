--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5 (Homebrew)
-- Dumped by pg_dump version 17.5 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: btree_gin; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gin WITH SCHEMA public;


--
-- Name: EXTENSION btree_gin; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION btree_gin IS 'support for indexing common datatypes in GIN';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: refresh_outbreak_data(); Type: FUNCTION; Schema: public; Owner: samirkolhe
--

CREATE FUNCTION public.refresh_outbreak_data() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    REFRESH MATERIALIZED VIEW CONCURRENTLY outbreak_trends;
    REFRESH MATERIALIZED VIEW CONCURRENTLY drug_popularity;
END;
$$;


ALTER FUNCTION public.refresh_outbreak_data() OWNER TO samirkolhe;

--
-- Name: refresh_snomed_complete_view(); Type: FUNCTION; Schema: public; Owner: samirkolhe
--

CREATE FUNCTION public.refresh_snomed_complete_view() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    REFRESH MATERIALIZED VIEW CONCURRENTLY snomed_drugs_complete;
END;
$$;


ALTER FUNCTION public.refresh_snomed_complete_view() OWNER TO samirkolhe;

--
-- Name: update_abhbp_search_vector(); Type: FUNCTION; Schema: public; Owner: samirkolhe
--

CREATE FUNCTION public.update_abhbp_search_vector() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.search_vector := 
        setweight(to_tsvector('english', COALESCE(NEW.package_code, '')), 'A') ||
        setweight(to_tsvector('english', COALESCE(NEW.package_name, '')), 'A') ||
        setweight(to_tsvector('english', COALESCE(NEW.specialty, '')), 'B');
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_abhbp_search_vector() OWNER TO samirkolhe;

--
-- Name: update_drug_search_vector(); Type: FUNCTION; Schema: public; Owner: samirkolhe
--

CREATE FUNCTION public.update_drug_search_vector() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.search_vector := 
        setweight(to_tsvector('english', COALESCE(NEW.brand_name, '')), 'A') ||
        setweight(to_tsvector('english', COALESCE(NEW.manufacturer, '')), 'B');
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_drug_search_vector() OWNER TO samirkolhe;

--
-- Name: update_generic_search_vector(); Type: FUNCTION; Schema: public; Owner: samirkolhe
--

CREATE FUNCTION public.update_generic_search_vector() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.search_vector := 
        setweight(to_tsvector('english', COALESCE(NEW.ingredient_name, '')), 'A') ||
        setweight(to_tsvector('english', COALESCE(NEW.indications, '')), 'B') ||
        setweight(to_tsvector('english', COALESCE(NEW.symptoms, '')), 'B') ||
        setweight(to_tsvector('english', COALESCE(NEW.conditions, '')), 'C');
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_generic_search_vector() OWNER TO samirkolhe;

--
-- Name: update_snomed_brand_search(); Type: FUNCTION; Schema: public; Owner: samirkolhe
--

CREATE FUNCTION public.update_snomed_brand_search() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.search_vector := 
        setweight(to_tsvector('english', COALESCE(NEW.brand_name, '')), 'A');
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_snomed_brand_search() OWNER TO samirkolhe;

--
-- Name: update_snomed_generic_search(); Type: FUNCTION; Schema: public; Owner: samirkolhe
--

CREATE FUNCTION public.update_snomed_generic_search() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.search_vector := 
        setweight(to_tsvector('english', COALESCE(NEW.generic_name, '')), 'A') ||
        setweight(to_tsvector('english', COALESCE(NEW.indication, '')), 'B') ||
        setweight(to_tsvector('english', COALESCE(NEW.therapeutic_role, '')), 'C');
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_snomed_generic_search() OWNER TO samirkolhe;

--
-- Name: update_snomed_product_search(); Type: FUNCTION; Schema: public; Owner: samirkolhe
--

CREATE FUNCTION public.update_snomed_product_search() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.search_vector := 
        setweight(to_tsvector('english', COALESCE(NEW.product_name, '')), 'A');
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_snomed_product_search() OWNER TO samirkolhe;

--
-- Name: update_snomed_supplier_search(); Type: FUNCTION; Schema: public; Owner: samirkolhe
--

CREATE FUNCTION public.update_snomed_supplier_search() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.search_vector := 
        setweight(to_tsvector('english', COALESCE(NEW.supplier_name, '')), 'A');
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_snomed_supplier_search() OWNER TO samirkolhe;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: abhbp_procedures; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.abhbp_procedures (
    procedure_id integer NOT NULL,
    package_code character varying(20) NOT NULL,
    package_name text NOT NULL,
    specialty character varying(100),
    procedure_type text,
    base_rate numeric(10,2),
    icd10_codes jsonb DEFAULT '[]'::jsonb,
    cpt_equivalent character varying(20),
    hbp_category character varying(50),
    empanelment_required boolean DEFAULT true,
    preauth_required boolean DEFAULT false,
    search_vector tsvector,
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.abhbp_procedures OWNER TO samirkolhe;

--
-- Name: abhbp_procedures_procedure_id_seq; Type: SEQUENCE; Schema: public; Owner: samirkolhe
--

CREATE SEQUENCE public.abhbp_procedures_procedure_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.abhbp_procedures_procedure_id_seq OWNER TO samirkolhe;

--
-- Name: abhbp_procedures_procedure_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: samirkolhe
--

ALTER SEQUENCE public.abhbp_procedures_procedure_id_seq OWNED BY public.abhbp_procedures.procedure_id;


--
-- Name: api_call_logs; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.api_call_logs (
    id integer NOT NULL,
    api_key character varying(100),
    endpoint character varying(255) NOT NULL,
    method character varying(10) NOT NULL,
    query_params text,
    request_body text,
    response_status integer,
    response_time_ms double precision,
    ip_address character varying(50),
    user_agent text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.api_call_logs OWNER TO samirkolhe;

--
-- Name: TABLE api_call_logs; Type: COMMENT; Schema: public; Owner: samirkolhe
--

COMMENT ON TABLE public.api_call_logs IS 'Stores all API calls for auditing and analytics';


--
-- Name: api_call_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: samirkolhe
--

CREATE SEQUENCE public.api_call_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.api_call_logs_id_seq OWNER TO samirkolhe;

--
-- Name: api_call_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: samirkolhe
--

ALTER SEQUENCE public.api_call_logs_id_seq OWNED BY public.api_call_logs.id;


--
-- Name: combination_drugs; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.combination_drugs (
    combination_id integer NOT NULL,
    brand_name character varying(200) NOT NULL,
    manufacturer character varying(200),
    ingredients jsonb,
    dosage_form character varying(50),
    mrp numeric(10,2),
    pack_size character varying(50),
    search_vector tsvector,
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.combination_drugs OWNER TO samirkolhe;

--
-- Name: combination_drugs_combination_id_seq; Type: SEQUENCE; Schema: public; Owner: samirkolhe
--

CREATE SEQUENCE public.combination_drugs_combination_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.combination_drugs_combination_id_seq OWNER TO samirkolhe;

--
-- Name: combination_drugs_combination_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: samirkolhe
--

ALTER SEQUENCE public.combination_drugs_combination_id_seq OWNED BY public.combination_drugs.combination_id;


--
-- Name: drug_contraindications; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.drug_contraindications (
    contraindication_id integer NOT NULL,
    drug_id integer,
    icd10_code character varying(20),
    contraindication_type character varying(20),
    reason text,
    alternative_drugs jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.drug_contraindications OWNER TO samirkolhe;

--
-- Name: drug_contraindications_contraindication_id_seq; Type: SEQUENCE; Schema: public; Owner: samirkolhe
--

CREATE SEQUENCE public.drug_contraindications_contraindication_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.drug_contraindications_contraindication_id_seq OWNER TO samirkolhe;

--
-- Name: drug_contraindications_contraindication_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: samirkolhe
--

ALTER SEQUENCE public.drug_contraindications_contraindication_id_seq OWNED BY public.drug_contraindications.contraindication_id;


--
-- Name: drug_interactions; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.drug_interactions (
    interaction_id integer NOT NULL,
    drug_a_id integer,
    drug_b_id integer,
    severity character varying(20),
    interaction_type character varying(50),
    description text,
    clinical_effect text,
    management text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.drug_interactions OWNER TO samirkolhe;

--
-- Name: drug_interactions_interaction_id_seq; Type: SEQUENCE; Schema: public; Owner: samirkolhe
--

CREATE SEQUENCE public.drug_interactions_interaction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.drug_interactions_interaction_id_seq OWNER TO samirkolhe;

--
-- Name: drug_interactions_interaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: samirkolhe
--

ALTER SEQUENCE public.drug_interactions_interaction_id_seq OWNED BY public.drug_interactions.interaction_id;


--
-- Name: prescription_drugs; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.prescription_drugs (
    id bigint NOT NULL,
    prescription_id bigint,
    snomed_id bigint,
    brand_name text,
    generic_name text,
    dosage text,
    duration text,
    quantity integer,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.prescription_drugs OWNER TO samirkolhe;

--
-- Name: prescriptions; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.prescriptions (
    prescription_id bigint NOT NULL,
    hospital_id character varying(50),
    doctor_id character varying(50),
    patient_age integer,
    patient_gender character(1),
    location character varying(100),
    icd10_code character varying(20),
    diagnosis text,
    prescribed_date date DEFAULT CURRENT_DATE,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.prescriptions OWNER TO samirkolhe;

--
-- Name: drug_popularity; Type: MATERIALIZED VIEW; Schema: public; Owner: samirkolhe
--

CREATE MATERIALIZED VIEW public.drug_popularity AS
 SELECT pd.snomed_id,
    pd.generic_name,
    p.icd10_code,
    p.location,
    count(*) AS prescription_count,
    count(DISTINCT p.hospital_id) AS hospital_count,
    date_trunc('month'::text, (p.prescribed_date)::timestamp with time zone) AS month
   FROM (public.prescription_drugs pd
     JOIN public.prescriptions p ON ((pd.prescription_id = p.prescription_id)))
  WHERE (p.prescribed_date >= (CURRENT_DATE - '6 mons'::interval))
  GROUP BY pd.snomed_id, pd.generic_name, p.icd10_code, p.location, (date_trunc('month'::text, (p.prescribed_date)::timestamp with time zone))
  WITH NO DATA;


ALTER MATERIALIZED VIEW public.drug_popularity OWNER TO samirkolhe;

--
-- Name: generic_ingredients; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.generic_ingredients (
    ingredient_id integer NOT NULL,
    rxnorm_cui character varying(20),
    ingredient_name character varying(200) NOT NULL,
    atc_code character varying(20),
    cas_number character varying(50),
    therapeutic_class character varying(100),
    pharmacological_class character varying(100),
    drug_category character varying(50),
    indications text,
    symptoms text,
    conditions text,
    ingredient_name_hindi text,
    ingredient_name_tamil text,
    ingredient_name_telugu text,
    search_vector tsvector,
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.generic_ingredients OWNER TO samirkolhe;

--
-- Name: generic_ingredients_ingredient_id_seq; Type: SEQUENCE; Schema: public; Owner: samirkolhe
--

CREATE SEQUENCE public.generic_ingredients_ingredient_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.generic_ingredients_ingredient_id_seq OWNER TO samirkolhe;

--
-- Name: generic_ingredients_ingredient_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: samirkolhe
--

ALTER SEQUENCE public.generic_ingredients_ingredient_id_seq OWNED BY public.generic_ingredients.ingredient_id;


--
-- Name: icd10_master; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.icd10_master (
    id integer NOT NULL,
    code character varying(20) NOT NULL,
    term text NOT NULL,
    short_desc text,
    chapter text,
    category character varying(10),
    parent_code character varying(20),
    active boolean DEFAULT true,
    billable boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
)
PARTITION BY RANGE (code);


ALTER TABLE public.icd10_master OWNER TO samirkolhe;

--
-- Name: icd10_master_id_seq; Type: SEQUENCE; Schema: public; Owner: samirkolhe
--

CREATE SEQUENCE public.icd10_master_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.icd10_master_id_seq OWNER TO samirkolhe;

--
-- Name: icd10_master_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: samirkolhe
--

ALTER SEQUENCE public.icd10_master_id_seq OWNED BY public.icd10_master.id;


--
-- Name: icd10_circulatory; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.icd10_circulatory (
    id integer DEFAULT nextval('public.icd10_master_id_seq'::regclass) NOT NULL,
    code character varying(20) NOT NULL,
    term text NOT NULL,
    short_desc text,
    chapter text,
    category character varying(10),
    parent_code character varying(20),
    active boolean DEFAULT true,
    billable boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.icd10_circulatory OWNER TO samirkolhe;

--
-- Name: icd10_codes; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.icd10_codes (
    id integer NOT NULL,
    code character varying(20) NOT NULL,
    term text NOT NULL,
    short_desc text,
    chapter text,
    category character varying(10),
    parent_code character varying(20),
    active boolean DEFAULT true,
    billable boolean DEFAULT true,
    search_vector tsvector,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.icd10_codes OWNER TO samirkolhe;

--
-- Name: icd10_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: samirkolhe
--

CREATE SEQUENCE public.icd10_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.icd10_codes_id_seq OWNER TO samirkolhe;

--
-- Name: icd10_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: samirkolhe
--

ALTER SEQUENCE public.icd10_codes_id_seq OWNED BY public.icd10_codes.id;


--
-- Name: icd10_congenital; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.icd10_congenital (
    id integer DEFAULT nextval('public.icd10_master_id_seq'::regclass) NOT NULL,
    code character varying(20) NOT NULL,
    term text NOT NULL,
    short_desc text,
    chapter text,
    category character varying(10),
    parent_code character varying(20),
    active boolean DEFAULT true,
    billable boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.icd10_congenital OWNER TO samirkolhe;

--
-- Name: icd10_digestive; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.icd10_digestive (
    id integer DEFAULT nextval('public.icd10_master_id_seq'::regclass) NOT NULL,
    code character varying(20) NOT NULL,
    term text NOT NULL,
    short_desc text,
    chapter text,
    category character varying(10),
    parent_code character varying(20),
    active boolean DEFAULT true,
    billable boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.icd10_digestive OWNER TO samirkolhe;

--
-- Name: icd10_endocrine_metabolic; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.icd10_endocrine_metabolic (
    id integer DEFAULT nextval('public.icd10_master_id_seq'::regclass) NOT NULL,
    code character varying(20) NOT NULL,
    term text NOT NULL,
    short_desc text,
    chapter text,
    category character varying(10),
    parent_code character varying(20),
    active boolean DEFAULT true,
    billable boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.icd10_endocrine_metabolic OWNER TO samirkolhe;

--
-- Name: icd10_external_causes; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.icd10_external_causes (
    id integer DEFAULT nextval('public.icd10_master_id_seq'::regclass) NOT NULL,
    code character varying(20) NOT NULL,
    term text NOT NULL,
    short_desc text,
    chapter text,
    category character varying(10),
    parent_code character varying(20),
    active boolean DEFAULT true,
    billable boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.icd10_external_causes OWNER TO samirkolhe;

--
-- Name: icd10_eye_ear; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.icd10_eye_ear (
    id integer DEFAULT nextval('public.icd10_master_id_seq'::regclass) NOT NULL,
    code character varying(20) NOT NULL,
    term text NOT NULL,
    short_desc text,
    chapter text,
    category character varying(10),
    parent_code character varying(20),
    active boolean DEFAULT true,
    billable boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.icd10_eye_ear OWNER TO samirkolhe;

--
-- Name: icd10_genitourinary; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.icd10_genitourinary (
    id integer DEFAULT nextval('public.icd10_master_id_seq'::regclass) NOT NULL,
    code character varying(20) NOT NULL,
    term text NOT NULL,
    short_desc text,
    chapter text,
    category character varying(10),
    parent_code character varying(20),
    active boolean DEFAULT true,
    billable boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.icd10_genitourinary OWNER TO samirkolhe;

--
-- Name: icd10_health_factors; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.icd10_health_factors (
    id integer DEFAULT nextval('public.icd10_master_id_seq'::regclass) NOT NULL,
    code character varying(20) NOT NULL,
    term text NOT NULL,
    short_desc text,
    chapter text,
    category character varying(10),
    parent_code character varying(20),
    active boolean DEFAULT true,
    billable boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.icd10_health_factors OWNER TO samirkolhe;

--
-- Name: icd10_infectious_parasitic; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.icd10_infectious_parasitic (
    id integer DEFAULT nextval('public.icd10_master_id_seq'::regclass) NOT NULL,
    code character varying(20) NOT NULL,
    term text NOT NULL,
    short_desc text,
    chapter text,
    category character varying(10),
    parent_code character varying(20),
    active boolean DEFAULT true,
    billable boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.icd10_infectious_parasitic OWNER TO samirkolhe;

--
-- Name: icd10_injury_poisoning; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.icd10_injury_poisoning (
    id integer DEFAULT nextval('public.icd10_master_id_seq'::regclass) NOT NULL,
    code character varying(20) NOT NULL,
    term text NOT NULL,
    short_desc text,
    chapter text,
    category character varying(10),
    parent_code character varying(20),
    active boolean DEFAULT true,
    billable boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.icd10_injury_poisoning OWNER TO samirkolhe;

--
-- Name: icd10_mental_behavioral; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.icd10_mental_behavioral (
    id integer DEFAULT nextval('public.icd10_master_id_seq'::regclass) NOT NULL,
    code character varying(20) NOT NULL,
    term text NOT NULL,
    short_desc text,
    chapter text,
    category character varying(10),
    parent_code character varying(20),
    active boolean DEFAULT true,
    billable boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.icd10_mental_behavioral OWNER TO samirkolhe;

--
-- Name: icd10_musculoskeletal; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.icd10_musculoskeletal (
    id integer DEFAULT nextval('public.icd10_master_id_seq'::regclass) NOT NULL,
    code character varying(20) NOT NULL,
    term text NOT NULL,
    short_desc text,
    chapter text,
    category character varying(10),
    parent_code character varying(20),
    active boolean DEFAULT true,
    billable boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.icd10_musculoskeletal OWNER TO samirkolhe;

--
-- Name: icd10_neoplasms_blood; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.icd10_neoplasms_blood (
    id integer DEFAULT nextval('public.icd10_master_id_seq'::regclass) NOT NULL,
    code character varying(20) NOT NULL,
    term text NOT NULL,
    short_desc text,
    chapter text,
    category character varying(10),
    parent_code character varying(20),
    active boolean DEFAULT true,
    billable boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.icd10_neoplasms_blood OWNER TO samirkolhe;

--
-- Name: icd10_nervous_system; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.icd10_nervous_system (
    id integer DEFAULT nextval('public.icd10_master_id_seq'::regclass) NOT NULL,
    code character varying(20) NOT NULL,
    term text NOT NULL,
    short_desc text,
    chapter text,
    category character varying(10),
    parent_code character varying(20),
    active boolean DEFAULT true,
    billable boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.icd10_nervous_system OWNER TO samirkolhe;

--
-- Name: icd10_perinatal; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.icd10_perinatal (
    id integer DEFAULT nextval('public.icd10_master_id_seq'::regclass) NOT NULL,
    code character varying(20) NOT NULL,
    term text NOT NULL,
    short_desc text,
    chapter text,
    category character varying(10),
    parent_code character varying(20),
    active boolean DEFAULT true,
    billable boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.icd10_perinatal OWNER TO samirkolhe;

--
-- Name: icd10_pregnancy_childbirth; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.icd10_pregnancy_childbirth (
    id integer DEFAULT nextval('public.icd10_master_id_seq'::regclass) NOT NULL,
    code character varying(20) NOT NULL,
    term text NOT NULL,
    short_desc text,
    chapter text,
    category character varying(10),
    parent_code character varying(20),
    active boolean DEFAULT true,
    billable boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.icd10_pregnancy_childbirth OWNER TO samirkolhe;

--
-- Name: icd10_respiratory; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.icd10_respiratory (
    id integer DEFAULT nextval('public.icd10_master_id_seq'::regclass) NOT NULL,
    code character varying(20) NOT NULL,
    term text NOT NULL,
    short_desc text,
    chapter text,
    category character varying(10),
    parent_code character varying(20),
    active boolean DEFAULT true,
    billable boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.icd10_respiratory OWNER TO samirkolhe;

--
-- Name: icd10_skin_subcutaneous; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.icd10_skin_subcutaneous (
    id integer DEFAULT nextval('public.icd10_master_id_seq'::regclass) NOT NULL,
    code character varying(20) NOT NULL,
    term text NOT NULL,
    short_desc text,
    chapter text,
    category character varying(10),
    parent_code character varying(20),
    active boolean DEFAULT true,
    billable boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.icd10_skin_subcutaneous OWNER TO samirkolhe;

--
-- Name: icd10_symptoms_signs; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.icd10_symptoms_signs (
    id integer DEFAULT nextval('public.icd10_master_id_seq'::regclass) NOT NULL,
    code character varying(20) NOT NULL,
    term text NOT NULL,
    short_desc text,
    chapter text,
    category character varying(10),
    parent_code character varying(20),
    active boolean DEFAULT true,
    billable boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.icd10_symptoms_signs OWNER TO samirkolhe;

--
-- Name: icd11_codes; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.icd11_codes (
    id integer NOT NULL,
    code character varying(20) NOT NULL,
    title text NOT NULL,
    definition text,
    chapter text,
    url text,
    search_vector tsvector,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.icd11_codes OWNER TO samirkolhe;

--
-- Name: icd11_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: samirkolhe
--

CREATE SEQUENCE public.icd11_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.icd11_codes_id_seq OWNER TO samirkolhe;

--
-- Name: icd11_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: samirkolhe
--

ALTER SEQUENCE public.icd11_codes_id_seq OWNED BY public.icd11_codes.id;


--
-- Name: indian_brand_drugs; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.indian_brand_drugs (
    brand_id integer NOT NULL,
    brand_name character varying(200) NOT NULL,
    manufacturer character varying(200),
    ingredient_id integer,
    rxnorm_cui character varying(20),
    strength character varying(50),
    dosage_form character varying(50),
    route character varying(50),
    schedule character varying(10),
    cdsco_approval character varying(50),
    mrp numeric(10,2),
    pack_size character varying(50),
    prescription_required boolean DEFAULT true,
    otc_available boolean DEFAULT false,
    brand_name_hindi text,
    brand_name_tamil text,
    search_vector tsvector,
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.indian_brand_drugs OWNER TO samirkolhe;

--
-- Name: indian_brand_drugs_brand_id_seq; Type: SEQUENCE; Schema: public; Owner: samirkolhe
--

CREATE SEQUENCE public.indian_brand_drugs_brand_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.indian_brand_drugs_brand_id_seq OWNER TO samirkolhe;

--
-- Name: indian_brand_drugs_brand_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: samirkolhe
--

ALTER SEQUENCE public.indian_brand_drugs_brand_id_seq OWNED BY public.indian_brand_drugs.brand_id;


--
-- Name: mv_chapter_stats; Type: MATERIALIZED VIEW; Schema: public; Owner: samirkolhe
--

CREATE MATERIALIZED VIEW public.mv_chapter_stats AS
 SELECT chapter,
    count(*) AS total_codes,
    count(*) FILTER (WHERE (active = true)) AS active_codes,
    count(*) FILTER (WHERE (billable = true)) AS billable_codes,
    min((code)::text) AS first_code,
    max((code)::text) AS last_code
   FROM public.icd10_codes
  GROUP BY chapter
  WITH NO DATA;


ALTER MATERIALIZED VIEW public.mv_chapter_stats OWNER TO samirkolhe;

--
-- Name: search_logs; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.search_logs (
    id integer NOT NULL,
    api_key character varying(100),
    query text NOT NULL,
    endpoint character varying(100),
    results_count integer,
    response_time_ms double precision,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.search_logs OWNER TO samirkolhe;

--
-- Name: TABLE search_logs; Type: COMMENT; Schema: public; Owner: samirkolhe
--

COMMENT ON TABLE public.search_logs IS 'Stores search queries for analytics and improvement';


--
-- Name: mv_popular_searches; Type: MATERIALIZED VIEW; Schema: public; Owner: samirkolhe
--

CREATE MATERIALIZED VIEW public.mv_popular_searches AS
 SELECT query,
    count(*) AS search_count,
    avg(response_time_ms) AS avg_response_time,
    avg(results_count) AS avg_results,
    max(created_at) AS last_searched
   FROM public.search_logs
  WHERE (created_at >= (CURRENT_DATE - '30 days'::interval))
  GROUP BY query
 HAVING (count(*) >= 5)
  ORDER BY (count(*)) DESC
 LIMIT 1000
  WITH NO DATA;


ALTER MATERIALIZED VIEW public.mv_popular_searches OWNER TO samirkolhe;

--
-- Name: outbreak_trends; Type: MATERIALIZED VIEW; Schema: public; Owner: samirkolhe
--

CREATE MATERIALIZED VIEW public.outbreak_trends AS
 SELECT location,
    icd10_code,
    diagnosis,
    date_trunc('week'::text, (prescribed_date)::timestamp with time zone) AS week,
    count(*) AS case_count,
    avg(patient_age) AS avg_age,
    count(
        CASE
            WHEN (patient_gender = 'M'::bpchar) THEN 1
            ELSE NULL::integer
        END) AS male_count,
    count(
        CASE
            WHEN (patient_gender = 'F'::bpchar) THEN 1
            ELSE NULL::integer
        END) AS female_count
   FROM public.prescriptions
  WHERE (prescribed_date >= (CURRENT_DATE - '56 days'::interval))
  GROUP BY location, icd10_code, diagnosis, (date_trunc('week'::text, (prescribed_date)::timestamp with time zone))
  WITH NO DATA;


ALTER MATERIALIZED VIEW public.outbreak_trends OWNER TO samirkolhe;

--
-- Name: prescription_drugs_id_seq; Type: SEQUENCE; Schema: public; Owner: samirkolhe
--

CREATE SEQUENCE public.prescription_drugs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.prescription_drugs_id_seq OWNER TO samirkolhe;

--
-- Name: prescription_drugs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: samirkolhe
--

ALTER SEQUENCE public.prescription_drugs_id_seq OWNED BY public.prescription_drugs.id;


--
-- Name: prescriptions_prescription_id_seq; Type: SEQUENCE; Schema: public; Owner: samirkolhe
--

CREATE SEQUENCE public.prescriptions_prescription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.prescriptions_prescription_id_seq OWNER TO samirkolhe;

--
-- Name: prescriptions_prescription_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: samirkolhe
--

ALTER SEQUENCE public.prescriptions_prescription_id_seq OWNED BY public.prescriptions.prescription_id;


--
-- Name: search_logs_master; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.search_logs_master (
    id bigint NOT NULL,
    user_id character varying(50),
    query text NOT NULL,
    results_count integer,
    response_time_ms double precision,
    cache_hit boolean,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
)
PARTITION BY RANGE (created_at);


ALTER TABLE public.search_logs_master OWNER TO samirkolhe;

--
-- Name: search_logs_master_id_seq; Type: SEQUENCE; Schema: public; Owner: samirkolhe
--

CREATE SEQUENCE public.search_logs_master_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.search_logs_master_id_seq OWNER TO samirkolhe;

--
-- Name: search_logs_master_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: samirkolhe
--

ALTER SEQUENCE public.search_logs_master_id_seq OWNED BY public.search_logs_master.id;


--
-- Name: search_logs_2026_01; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.search_logs_2026_01 (
    id bigint DEFAULT nextval('public.search_logs_master_id_seq'::regclass) NOT NULL,
    user_id character varying(50),
    query text NOT NULL,
    results_count integer,
    response_time_ms double precision,
    cache_hit boolean,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.search_logs_2026_01 OWNER TO samirkolhe;

--
-- Name: search_logs_2026_02; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.search_logs_2026_02 (
    id bigint DEFAULT nextval('public.search_logs_master_id_seq'::regclass) NOT NULL,
    user_id character varying(50),
    query text NOT NULL,
    results_count integer,
    response_time_ms double precision,
    cache_hit boolean,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.search_logs_2026_02 OWNER TO samirkolhe;

--
-- Name: search_logs_2026_03; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.search_logs_2026_03 (
    id bigint DEFAULT nextval('public.search_logs_master_id_seq'::regclass) NOT NULL,
    user_id character varying(50),
    query text NOT NULL,
    results_count integer,
    response_time_ms double precision,
    cache_hit boolean,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.search_logs_2026_03 OWNER TO samirkolhe;

--
-- Name: search_logs_2026_04; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.search_logs_2026_04 (
    id bigint DEFAULT nextval('public.search_logs_master_id_seq'::regclass) NOT NULL,
    user_id character varying(50),
    query text NOT NULL,
    results_count integer,
    response_time_ms double precision,
    cache_hit boolean,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.search_logs_2026_04 OWNER TO samirkolhe;

--
-- Name: search_logs_2026_05; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.search_logs_2026_05 (
    id bigint DEFAULT nextval('public.search_logs_master_id_seq'::regclass) NOT NULL,
    user_id character varying(50),
    query text NOT NULL,
    results_count integer,
    response_time_ms double precision,
    cache_hit boolean,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.search_logs_2026_05 OWNER TO samirkolhe;

--
-- Name: search_logs_2026_06; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.search_logs_2026_06 (
    id bigint DEFAULT nextval('public.search_logs_master_id_seq'::regclass) NOT NULL,
    user_id character varying(50),
    query text NOT NULL,
    results_count integer,
    response_time_ms double precision,
    cache_hit boolean,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.search_logs_2026_06 OWNER TO samirkolhe;

--
-- Name: search_logs_2026_07; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.search_logs_2026_07 (
    id bigint DEFAULT nextval('public.search_logs_master_id_seq'::regclass) NOT NULL,
    user_id character varying(50),
    query text NOT NULL,
    results_count integer,
    response_time_ms double precision,
    cache_hit boolean,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.search_logs_2026_07 OWNER TO samirkolhe;

--
-- Name: search_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: samirkolhe
--

CREATE SEQUENCE public.search_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.search_logs_id_seq OWNER TO samirkolhe;

--
-- Name: search_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: samirkolhe
--

ALTER SEQUENCE public.search_logs_id_seq OWNED BY public.search_logs.id;


--
-- Name: snomed_brands; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.snomed_brands (
    snomed_id bigint NOT NULL,
    brand_name text NOT NULL,
    product_id bigint,
    supplier_id bigint,
    generic_id bigint,
    license_number character varying(100),
    license_status character varying(20),
    excipient text,
    last_updated date,
    search_vector tsvector,
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    route_of_administration character varying(50)
);


ALTER TABLE public.snomed_brands OWNER TO samirkolhe;

--
-- Name: snomed_drug_classes; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.snomed_drug_classes (
    drug_id bigint NOT NULL,
    drug_name character varying(500),
    is_antibiotic boolean DEFAULT false,
    is_analgesic boolean DEFAULT false,
    is_antihypertensive boolean DEFAULT false,
    is_antidiabetic boolean DEFAULT false,
    is_antiinflammatory boolean DEFAULT false,
    drug_class character varying(200),
    class_hierarchy text[]
);


ALTER TABLE public.snomed_drug_classes OWNER TO samirkolhe;

--
-- Name: snomed_drug_definitions; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.snomed_drug_definitions (
    id bigint NOT NULL,
    drug_id bigint NOT NULL,
    definition text,
    language_code character varying(5) DEFAULT 'en'::character varying
);


ALTER TABLE public.snomed_drug_definitions OWNER TO samirkolhe;

--
-- Name: snomed_drug_definitions_id_seq; Type: SEQUENCE; Schema: public; Owner: samirkolhe
--

CREATE SEQUENCE public.snomed_drug_definitions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.snomed_drug_definitions_id_seq OWNER TO samirkolhe;

--
-- Name: snomed_drug_definitions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: samirkolhe
--

ALTER SEQUENCE public.snomed_drug_definitions_id_seq OWNED BY public.snomed_drug_definitions.id;


--
-- Name: snomed_drug_dosages; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.snomed_drug_dosages (
    id bigint NOT NULL,
    drug_id bigint NOT NULL,
    attribute_type character varying(100),
    value_numeric numeric(10,2),
    value_text character varying(100),
    unit_code bigint
);


ALTER TABLE public.snomed_drug_dosages OWNER TO samirkolhe;

--
-- Name: snomed_drug_dosages_id_seq; Type: SEQUENCE; Schema: public; Owner: samirkolhe
--

CREATE SEQUENCE public.snomed_drug_dosages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.snomed_drug_dosages_id_seq OWNER TO samirkolhe;

--
-- Name: snomed_drug_dosages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: samirkolhe
--

ALTER SEQUENCE public.snomed_drug_dosages_id_seq OWNED BY public.snomed_drug_dosages.id;


--
-- Name: snomed_drug_forms; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.snomed_drug_forms (
    snomed_id bigint NOT NULL,
    form_name text NOT NULL,
    form_description text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.snomed_drug_forms OWNER TO samirkolhe;

--
-- Name: snomed_drug_hierarchy; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.snomed_drug_hierarchy (
    id bigint NOT NULL,
    drug_id bigint NOT NULL,
    parent_id bigint NOT NULL,
    relationship_type character varying(50) DEFAULT 'IS-A'::character varying,
    active boolean DEFAULT true
);


ALTER TABLE public.snomed_drug_hierarchy OWNER TO samirkolhe;

--
-- Name: snomed_drug_hierarchy_id_seq; Type: SEQUENCE; Schema: public; Owner: samirkolhe
--

CREATE SEQUENCE public.snomed_drug_hierarchy_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.snomed_drug_hierarchy_id_seq OWNER TO samirkolhe;

--
-- Name: snomed_drug_hierarchy_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: samirkolhe
--

ALTER SEQUENCE public.snomed_drug_hierarchy_id_seq OWNED BY public.snomed_drug_hierarchy.id;


--
-- Name: snomed_generics; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.snomed_generics (
    snomed_id bigint NOT NULL,
    generic_name text NOT NULL,
    substance_ids text,
    route_of_admin text,
    dose_form text,
    therapeutic_role text,
    indication text,
    contra_indication text,
    drug_interactions text,
    drug_classification text,
    source_regulatory text,
    last_updated date,
    search_vector tsvector,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.snomed_generics OWNER TO samirkolhe;

--
-- Name: snomed_products; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.snomed_products (
    snomed_id bigint NOT NULL,
    product_name text NOT NULL,
    search_vector tsvector,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.snomed_products OWNER TO samirkolhe;

--
-- Name: snomed_suppliers; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.snomed_suppliers (
    snomed_id bigint NOT NULL,
    supplier_name text NOT NULL,
    country character varying(100),
    search_vector tsvector,
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.snomed_suppliers OWNER TO samirkolhe;

--
-- Name: snomed_drugs_complete; Type: MATERIALIZED VIEW; Schema: public; Owner: samirkolhe
--

CREATE MATERIALIZED VIEW public.snomed_drugs_complete AS
 SELECT b.snomed_id AS brand_snomed_id,
    b.brand_name,
    b.license_status,
    b.active,
    g.snomed_id AS generic_snomed_id,
    g.generic_name,
    g.indication,
    g.contra_indication,
    g.therapeutic_role,
    g.dose_form,
    p.product_name,
    s.supplier_name,
    s.country AS manufacturer_country,
    b.search_vector AS brand_search,
    g.search_vector AS generic_search
   FROM (((public.snomed_brands b
     LEFT JOIN public.snomed_generics g ON ((b.generic_id = g.snomed_id)))
     LEFT JOIN public.snomed_products p ON ((b.product_id = p.snomed_id)))
     LEFT JOIN public.snomed_suppliers s ON ((b.supplier_id = s.snomed_id)))
  WHERE (b.active = true)
  WITH NO DATA;


ALTER MATERIALIZED VIEW public.snomed_drugs_complete OWNER TO samirkolhe;

--
-- Name: snomed_etl_log; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.snomed_etl_log (
    log_id integer NOT NULL,
    table_name character varying(50),
    records_loaded integer,
    records_failed integer,
    execution_time_ms integer,
    status character varying(20),
    error_message text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.snomed_etl_log OWNER TO samirkolhe;

--
-- Name: snomed_etl_log_log_id_seq; Type: SEQUENCE; Schema: public; Owner: samirkolhe
--

CREATE SEQUENCE public.snomed_etl_log_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.snomed_etl_log_log_id_seq OWNER TO samirkolhe;

--
-- Name: snomed_etl_log_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: samirkolhe
--

ALTER SEQUENCE public.snomed_etl_log_log_id_seq OWNED BY public.snomed_etl_log.log_id;


--
-- Name: snomed_routes; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.snomed_routes (
    snomed_id bigint NOT NULL,
    route_name text NOT NULL,
    route_description text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.snomed_routes OWNER TO samirkolhe;

--
-- Name: snomed_substances; Type: TABLE; Schema: public; Owner: samirkolhe
--

CREATE TABLE public.snomed_substances (
    snomed_id bigint NOT NULL,
    substance_name text NOT NULL,
    cas_number character varying(50),
    unii character varying(20),
    substance_description text,
    molecular_weight character varying(50),
    toxicity text,
    smile text,
    inchi text,
    iupac_name text,
    molecular_formula character varying(200),
    last_updated date,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.snomed_substances OWNER TO samirkolhe;

--
-- Name: icd10_circulatory; Type: TABLE ATTACH; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.icd10_master ATTACH PARTITION public.icd10_circulatory FOR VALUES FROM ('I00') TO ('I99Z');


--
-- Name: icd10_congenital; Type: TABLE ATTACH; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.icd10_master ATTACH PARTITION public.icd10_congenital FOR VALUES FROM ('Q00') TO ('Q99Z');


--
-- Name: icd10_digestive; Type: TABLE ATTACH; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.icd10_master ATTACH PARTITION public.icd10_digestive FOR VALUES FROM ('K00') TO ('K95Z');


--
-- Name: icd10_endocrine_metabolic; Type: TABLE ATTACH; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.icd10_master ATTACH PARTITION public.icd10_endocrine_metabolic FOR VALUES FROM ('E00') TO ('E89Z');


--
-- Name: icd10_external_causes; Type: TABLE ATTACH; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.icd10_master ATTACH PARTITION public.icd10_external_causes FOR VALUES FROM ('V01') TO ('Y99Z');


--
-- Name: icd10_eye_ear; Type: TABLE ATTACH; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.icd10_master ATTACH PARTITION public.icd10_eye_ear FOR VALUES FROM ('H00') TO ('H95Z');


--
-- Name: icd10_genitourinary; Type: TABLE ATTACH; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.icd10_master ATTACH PARTITION public.icd10_genitourinary FOR VALUES FROM ('N00') TO ('N99Z');


--
-- Name: icd10_health_factors; Type: TABLE ATTACH; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.icd10_master ATTACH PARTITION public.icd10_health_factors FOR VALUES FROM ('Z00') TO ('Z99Z');


--
-- Name: icd10_infectious_parasitic; Type: TABLE ATTACH; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.icd10_master ATTACH PARTITION public.icd10_infectious_parasitic FOR VALUES FROM ('A00') TO ('B99Z');


--
-- Name: icd10_injury_poisoning; Type: TABLE ATTACH; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.icd10_master ATTACH PARTITION public.icd10_injury_poisoning FOR VALUES FROM ('S00') TO ('T88Z');


--
-- Name: icd10_mental_behavioral; Type: TABLE ATTACH; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.icd10_master ATTACH PARTITION public.icd10_mental_behavioral FOR VALUES FROM ('F01') TO ('F99Z');


--
-- Name: icd10_musculoskeletal; Type: TABLE ATTACH; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.icd10_master ATTACH PARTITION public.icd10_musculoskeletal FOR VALUES FROM ('M00') TO ('M99Z');


--
-- Name: icd10_neoplasms_blood; Type: TABLE ATTACH; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.icd10_master ATTACH PARTITION public.icd10_neoplasms_blood FOR VALUES FROM ('C00') TO ('D89Z');


--
-- Name: icd10_nervous_system; Type: TABLE ATTACH; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.icd10_master ATTACH PARTITION public.icd10_nervous_system FOR VALUES FROM ('G00') TO ('G99Z');


--
-- Name: icd10_perinatal; Type: TABLE ATTACH; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.icd10_master ATTACH PARTITION public.icd10_perinatal FOR VALUES FROM ('P00') TO ('P96Z');


--
-- Name: icd10_pregnancy_childbirth; Type: TABLE ATTACH; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.icd10_master ATTACH PARTITION public.icd10_pregnancy_childbirth FOR VALUES FROM ('O00') TO ('O9AZ');


--
-- Name: icd10_respiratory; Type: TABLE ATTACH; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.icd10_master ATTACH PARTITION public.icd10_respiratory FOR VALUES FROM ('J00') TO ('J99Z');


--
-- Name: icd10_skin_subcutaneous; Type: TABLE ATTACH; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.icd10_master ATTACH PARTITION public.icd10_skin_subcutaneous FOR VALUES FROM ('L00') TO ('L99Z');


--
-- Name: icd10_symptoms_signs; Type: TABLE ATTACH; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.icd10_master ATTACH PARTITION public.icd10_symptoms_signs FOR VALUES FROM ('R00') TO ('R99Z');


--
-- Name: search_logs_2026_01; Type: TABLE ATTACH; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.search_logs_master ATTACH PARTITION public.search_logs_2026_01 FOR VALUES FROM ('2026-01-01 00:00:00') TO ('2026-02-01 00:00:00');


--
-- Name: search_logs_2026_02; Type: TABLE ATTACH; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.search_logs_master ATTACH PARTITION public.search_logs_2026_02 FOR VALUES FROM ('2026-02-01 00:00:00') TO ('2026-03-01 00:00:00');


--
-- Name: search_logs_2026_03; Type: TABLE ATTACH; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.search_logs_master ATTACH PARTITION public.search_logs_2026_03 FOR VALUES FROM ('2026-03-01 00:00:00') TO ('2026-04-01 00:00:00');


--
-- Name: search_logs_2026_04; Type: TABLE ATTACH; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.search_logs_master ATTACH PARTITION public.search_logs_2026_04 FOR VALUES FROM ('2026-04-01 00:00:00') TO ('2026-05-01 00:00:00');


--
-- Name: search_logs_2026_05; Type: TABLE ATTACH; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.search_logs_master ATTACH PARTITION public.search_logs_2026_05 FOR VALUES FROM ('2026-05-01 00:00:00') TO ('2026-06-01 00:00:00');


--
-- Name: search_logs_2026_06; Type: TABLE ATTACH; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.search_logs_master ATTACH PARTITION public.search_logs_2026_06 FOR VALUES FROM ('2026-06-01 00:00:00') TO ('2026-07-01 00:00:00');


--
-- Name: search_logs_2026_07; Type: TABLE ATTACH; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.search_logs_master ATTACH PARTITION public.search_logs_2026_07 FOR VALUES FROM ('2026-07-01 00:00:00') TO ('2026-08-01 00:00:00');


--
-- Name: abhbp_procedures procedure_id; Type: DEFAULT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.abhbp_procedures ALTER COLUMN procedure_id SET DEFAULT nextval('public.abhbp_procedures_procedure_id_seq'::regclass);


--
-- Name: api_call_logs id; Type: DEFAULT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.api_call_logs ALTER COLUMN id SET DEFAULT nextval('public.api_call_logs_id_seq'::regclass);


--
-- Name: combination_drugs combination_id; Type: DEFAULT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.combination_drugs ALTER COLUMN combination_id SET DEFAULT nextval('public.combination_drugs_combination_id_seq'::regclass);


--
-- Name: drug_contraindications contraindication_id; Type: DEFAULT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.drug_contraindications ALTER COLUMN contraindication_id SET DEFAULT nextval('public.drug_contraindications_contraindication_id_seq'::regclass);


--
-- Name: drug_interactions interaction_id; Type: DEFAULT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.drug_interactions ALTER COLUMN interaction_id SET DEFAULT nextval('public.drug_interactions_interaction_id_seq'::regclass);


--
-- Name: generic_ingredients ingredient_id; Type: DEFAULT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.generic_ingredients ALTER COLUMN ingredient_id SET DEFAULT nextval('public.generic_ingredients_ingredient_id_seq'::regclass);


--
-- Name: icd10_codes id; Type: DEFAULT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.icd10_codes ALTER COLUMN id SET DEFAULT nextval('public.icd10_codes_id_seq'::regclass);


--
-- Name: icd10_master id; Type: DEFAULT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.icd10_master ALTER COLUMN id SET DEFAULT nextval('public.icd10_master_id_seq'::regclass);


--
-- Name: icd11_codes id; Type: DEFAULT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.icd11_codes ALTER COLUMN id SET DEFAULT nextval('public.icd11_codes_id_seq'::regclass);


--
-- Name: indian_brand_drugs brand_id; Type: DEFAULT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.indian_brand_drugs ALTER COLUMN brand_id SET DEFAULT nextval('public.indian_brand_drugs_brand_id_seq'::regclass);


--
-- Name: prescription_drugs id; Type: DEFAULT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.prescription_drugs ALTER COLUMN id SET DEFAULT nextval('public.prescription_drugs_id_seq'::regclass);


--
-- Name: prescriptions prescription_id; Type: DEFAULT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.prescriptions ALTER COLUMN prescription_id SET DEFAULT nextval('public.prescriptions_prescription_id_seq'::regclass);


--
-- Name: search_logs id; Type: DEFAULT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.search_logs ALTER COLUMN id SET DEFAULT nextval('public.search_logs_id_seq'::regclass);


--
-- Name: search_logs_master id; Type: DEFAULT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.search_logs_master ALTER COLUMN id SET DEFAULT nextval('public.search_logs_master_id_seq'::regclass);


--
-- Name: snomed_drug_definitions id; Type: DEFAULT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.snomed_drug_definitions ALTER COLUMN id SET DEFAULT nextval('public.snomed_drug_definitions_id_seq'::regclass);


--
-- Name: snomed_drug_dosages id; Type: DEFAULT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.snomed_drug_dosages ALTER COLUMN id SET DEFAULT nextval('public.snomed_drug_dosages_id_seq'::regclass);


--
-- Name: snomed_drug_hierarchy id; Type: DEFAULT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.snomed_drug_hierarchy ALTER COLUMN id SET DEFAULT nextval('public.snomed_drug_hierarchy_id_seq'::regclass);


--
-- Name: snomed_etl_log log_id; Type: DEFAULT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.snomed_etl_log ALTER COLUMN log_id SET DEFAULT nextval('public.snomed_etl_log_log_id_seq'::regclass);


--
-- Name: abhbp_procedures abhbp_procedures_package_code_key; Type: CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.abhbp_procedures
    ADD CONSTRAINT abhbp_procedures_package_code_key UNIQUE (package_code);


--
-- Name: abhbp_procedures abhbp_procedures_pkey; Type: CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.abhbp_procedures
    ADD CONSTRAINT abhbp_procedures_pkey PRIMARY KEY (procedure_id);


--
-- Name: api_call_logs api_call_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.api_call_logs
    ADD CONSTRAINT api_call_logs_pkey PRIMARY KEY (id);


--
-- Name: combination_drugs combination_drugs_pkey; Type: CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.combination_drugs
    ADD CONSTRAINT combination_drugs_pkey PRIMARY KEY (combination_id);


--
-- Name: drug_contraindications drug_contraindications_pkey; Type: CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.drug_contraindications
    ADD CONSTRAINT drug_contraindications_pkey PRIMARY KEY (contraindication_id);


--
-- Name: drug_interactions drug_interactions_pkey; Type: CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.drug_interactions
    ADD CONSTRAINT drug_interactions_pkey PRIMARY KEY (interaction_id);


--
-- Name: generic_ingredients generic_ingredients_pkey; Type: CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.generic_ingredients
    ADD CONSTRAINT generic_ingredients_pkey PRIMARY KEY (ingredient_id);


--
-- Name: generic_ingredients generic_ingredients_rxnorm_cui_key; Type: CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.generic_ingredients
    ADD CONSTRAINT generic_ingredients_rxnorm_cui_key UNIQUE (rxnorm_cui);


--
-- Name: icd10_codes icd10_codes_code_key; Type: CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.icd10_codes
    ADD CONSTRAINT icd10_codes_code_key UNIQUE (code);


--
-- Name: icd10_codes icd10_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.icd10_codes
    ADD CONSTRAINT icd10_codes_pkey PRIMARY KEY (id);


--
-- Name: icd11_codes icd11_codes_code_key; Type: CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.icd11_codes
    ADD CONSTRAINT icd11_codes_code_key UNIQUE (code);


--
-- Name: icd11_codes icd11_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.icd11_codes
    ADD CONSTRAINT icd11_codes_pkey PRIMARY KEY (id);


--
-- Name: indian_brand_drugs indian_brand_drugs_brand_name_strength_dosage_form_key; Type: CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.indian_brand_drugs
    ADD CONSTRAINT indian_brand_drugs_brand_name_strength_dosage_form_key UNIQUE (brand_name, strength, dosage_form);


--
-- Name: indian_brand_drugs indian_brand_drugs_pkey; Type: CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.indian_brand_drugs
    ADD CONSTRAINT indian_brand_drugs_pkey PRIMARY KEY (brand_id);


--
-- Name: prescription_drugs prescription_drugs_pkey; Type: CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.prescription_drugs
    ADD CONSTRAINT prescription_drugs_pkey PRIMARY KEY (id);


--
-- Name: prescriptions prescriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.prescriptions
    ADD CONSTRAINT prescriptions_pkey PRIMARY KEY (prescription_id);


--
-- Name: search_logs search_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.search_logs
    ADD CONSTRAINT search_logs_pkey PRIMARY KEY (id);


--
-- Name: snomed_brands snomed_brands_pkey; Type: CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.snomed_brands
    ADD CONSTRAINT snomed_brands_pkey PRIMARY KEY (snomed_id);


--
-- Name: snomed_drug_classes snomed_drug_classes_pkey; Type: CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.snomed_drug_classes
    ADD CONSTRAINT snomed_drug_classes_pkey PRIMARY KEY (drug_id);


--
-- Name: snomed_drug_definitions snomed_drug_definitions_drug_id_key; Type: CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.snomed_drug_definitions
    ADD CONSTRAINT snomed_drug_definitions_drug_id_key UNIQUE (drug_id);


--
-- Name: snomed_drug_definitions snomed_drug_definitions_pkey; Type: CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.snomed_drug_definitions
    ADD CONSTRAINT snomed_drug_definitions_pkey PRIMARY KEY (id);


--
-- Name: snomed_drug_dosages snomed_drug_dosages_drug_id_attribute_type_key; Type: CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.snomed_drug_dosages
    ADD CONSTRAINT snomed_drug_dosages_drug_id_attribute_type_key UNIQUE (drug_id, attribute_type);


--
-- Name: snomed_drug_dosages snomed_drug_dosages_pkey; Type: CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.snomed_drug_dosages
    ADD CONSTRAINT snomed_drug_dosages_pkey PRIMARY KEY (id);


--
-- Name: snomed_drug_forms snomed_drug_forms_pkey; Type: CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.snomed_drug_forms
    ADD CONSTRAINT snomed_drug_forms_pkey PRIMARY KEY (snomed_id);


--
-- Name: snomed_drug_hierarchy snomed_drug_hierarchy_drug_id_parent_id_key; Type: CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.snomed_drug_hierarchy
    ADD CONSTRAINT snomed_drug_hierarchy_drug_id_parent_id_key UNIQUE (drug_id, parent_id);


--
-- Name: snomed_drug_hierarchy snomed_drug_hierarchy_pkey; Type: CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.snomed_drug_hierarchy
    ADD CONSTRAINT snomed_drug_hierarchy_pkey PRIMARY KEY (id);


--
-- Name: snomed_etl_log snomed_etl_log_pkey; Type: CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.snomed_etl_log
    ADD CONSTRAINT snomed_etl_log_pkey PRIMARY KEY (log_id);


--
-- Name: snomed_generics snomed_generics_pkey; Type: CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.snomed_generics
    ADD CONSTRAINT snomed_generics_pkey PRIMARY KEY (snomed_id);


--
-- Name: snomed_products snomed_products_pkey; Type: CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.snomed_products
    ADD CONSTRAINT snomed_products_pkey PRIMARY KEY (snomed_id);


--
-- Name: snomed_routes snomed_routes_pkey; Type: CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.snomed_routes
    ADD CONSTRAINT snomed_routes_pkey PRIMARY KEY (snomed_id);


--
-- Name: snomed_substances snomed_substances_pkey; Type: CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.snomed_substances
    ADD CONSTRAINT snomed_substances_pkey PRIMARY KEY (snomed_id);


--
-- Name: snomed_suppliers snomed_suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.snomed_suppliers
    ADD CONSTRAINT snomed_suppliers_pkey PRIMARY KEY (snomed_id);


--
-- Name: idx_abhbp_icd10; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_abhbp_icd10 ON public.abhbp_procedures USING gin (icd10_codes);


--
-- Name: idx_abhbp_package_code; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_abhbp_package_code ON public.abhbp_procedures USING btree (package_code);


--
-- Name: idx_abhbp_search; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_abhbp_search ON public.abhbp_procedures USING gin (search_vector);


--
-- Name: idx_abhbp_specialty; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_abhbp_specialty ON public.abhbp_procedures USING btree (specialty);


--
-- Name: idx_api_logs_api_key; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_api_logs_api_key ON public.api_call_logs USING btree (api_key);


--
-- Name: idx_api_logs_created_at; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_api_logs_created_at ON public.api_call_logs USING btree (created_at);


--
-- Name: idx_api_logs_endpoint; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_api_logs_endpoint ON public.api_call_logs USING btree (endpoint);


--
-- Name: idx_atc_code; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_atc_code ON public.generic_ingredients USING btree (atc_code);


--
-- Name: idx_brand_ingredient; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_brand_ingredient ON public.indian_brand_drugs USING btree (ingredient_id);


--
-- Name: idx_brand_manufacturer; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_brand_manufacturer ON public.indian_brand_drugs USING btree (manufacturer);


--
-- Name: idx_brand_name; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_brand_name ON public.indian_brand_drugs USING btree (brand_name);


--
-- Name: idx_brand_rxnorm; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_brand_rxnorm ON public.indian_brand_drugs USING btree (rxnorm_cui);


--
-- Name: idx_brand_search; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_brand_search ON public.indian_brand_drugs USING gin (search_vector);


--
-- Name: idx_circulatory_active; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_circulatory_active ON public.icd10_circulatory USING btree (active) WHERE (active = true);


--
-- Name: idx_circulatory_code; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_circulatory_code ON public.icd10_circulatory USING btree (code);


--
-- Name: idx_circulatory_term_gin; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_circulatory_term_gin ON public.icd10_circulatory USING gin (to_tsvector('english'::regconfig, term));


--
-- Name: idx_classes_analgesic; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_classes_analgesic ON public.snomed_drug_classes USING btree (is_analgesic) WHERE is_analgesic;


--
-- Name: idx_classes_antibiotic; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_classes_antibiotic ON public.snomed_drug_classes USING btree (is_antibiotic) WHERE is_antibiotic;


--
-- Name: idx_combination_ingredients; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_combination_ingredients ON public.combination_drugs USING gin (ingredients);


--
-- Name: idx_combination_search; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_combination_search ON public.combination_drugs USING gin (search_vector);


--
-- Name: idx_congenital_active; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_congenital_active ON public.icd10_congenital USING btree (active) WHERE (active = true);


--
-- Name: idx_congenital_code; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_congenital_code ON public.icd10_congenital USING btree (code);


--
-- Name: idx_congenital_term_gin; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_congenital_term_gin ON public.icd10_congenital USING gin (to_tsvector('english'::regconfig, term));


--
-- Name: idx_contraindication_drug; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_contraindication_drug ON public.drug_contraindications USING btree (drug_id);


--
-- Name: idx_contraindication_icd10; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_contraindication_icd10 ON public.drug_contraindications USING btree (icd10_code);


--
-- Name: idx_definitions_drug; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_definitions_drug ON public.snomed_drug_definitions USING btree (drug_id);


--
-- Name: idx_digestive_active; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_digestive_active ON public.icd10_digestive USING btree (active) WHERE (active = true);


--
-- Name: idx_digestive_code; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_digestive_code ON public.icd10_digestive USING btree (code);


--
-- Name: idx_digestive_term_gin; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_digestive_term_gin ON public.icd10_digestive USING gin (to_tsvector('english'::regconfig, term));


--
-- Name: idx_dosages_drug; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_dosages_drug ON public.snomed_drug_dosages USING btree (drug_id);


--
-- Name: idx_drug_popularity_icd10; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_drug_popularity_icd10 ON public.drug_popularity USING btree (icd10_code);


--
-- Name: idx_drug_popularity_location; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_drug_popularity_location ON public.drug_popularity USING btree (location);


--
-- Name: idx_endocrine_metabolic_active; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_endocrine_metabolic_active ON public.icd10_endocrine_metabolic USING btree (active) WHERE (active = true);


--
-- Name: idx_endocrine_metabolic_code; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_endocrine_metabolic_code ON public.icd10_endocrine_metabolic USING btree (code);


--
-- Name: idx_endocrine_metabolic_term_gin; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_endocrine_metabolic_term_gin ON public.icd10_endocrine_metabolic USING gin (to_tsvector('english'::regconfig, term));


--
-- Name: idx_external_causes_active; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_external_causes_active ON public.icd10_external_causes USING btree (active) WHERE (active = true);


--
-- Name: idx_external_causes_code; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_external_causes_code ON public.icd10_external_causes USING btree (code);


--
-- Name: idx_external_causes_term_gin; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_external_causes_term_gin ON public.icd10_external_causes USING gin (to_tsvector('english'::regconfig, term));


--
-- Name: idx_eye_ear_active; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_eye_ear_active ON public.icd10_eye_ear USING btree (active) WHERE (active = true);


--
-- Name: idx_eye_ear_code; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_eye_ear_code ON public.icd10_eye_ear USING btree (code);


--
-- Name: idx_eye_ear_term_gin; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_eye_ear_term_gin ON public.icd10_eye_ear USING gin (to_tsvector('english'::regconfig, term));


--
-- Name: idx_genitourinary_active; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_genitourinary_active ON public.icd10_genitourinary USING btree (active) WHERE (active = true);


--
-- Name: idx_genitourinary_code; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_genitourinary_code ON public.icd10_genitourinary USING btree (code);


--
-- Name: idx_genitourinary_term_gin; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_genitourinary_term_gin ON public.icd10_genitourinary USING gin (to_tsvector('english'::regconfig, term));


--
-- Name: idx_health_factors_active; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_health_factors_active ON public.icd10_health_factors USING btree (active) WHERE (active = true);


--
-- Name: idx_health_factors_code; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_health_factors_code ON public.icd10_health_factors USING btree (code);


--
-- Name: idx_health_factors_term_gin; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_health_factors_term_gin ON public.icd10_health_factors USING gin (to_tsvector('english'::regconfig, term));


--
-- Name: idx_hierarchy_drug; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_hierarchy_drug ON public.snomed_drug_hierarchy USING btree (drug_id);


--
-- Name: idx_hierarchy_parent; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_hierarchy_parent ON public.snomed_drug_hierarchy USING btree (parent_id);


--
-- Name: idx_icd10_code; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_icd10_code ON public.icd10_codes USING btree (code);


--
-- Name: idx_icd10_search; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_icd10_search ON public.icd10_codes USING gin (search_vector);


--
-- Name: idx_icd11_code; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_icd11_code ON public.icd11_codes USING btree (code);


--
-- Name: idx_icd11_search; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_icd11_search ON public.icd11_codes USING gin (search_vector);


--
-- Name: idx_infectious_parasitic_active; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_infectious_parasitic_active ON public.icd10_infectious_parasitic USING btree (active) WHERE (active = true);


--
-- Name: idx_infectious_parasitic_code; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_infectious_parasitic_code ON public.icd10_infectious_parasitic USING btree (code);


--
-- Name: idx_infectious_parasitic_term_gin; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_infectious_parasitic_term_gin ON public.icd10_infectious_parasitic USING gin (to_tsvector('english'::regconfig, term));


--
-- Name: idx_ingredient_name; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_ingredient_name ON public.generic_ingredients USING btree (ingredient_name);


--
-- Name: idx_ingredient_search; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_ingredient_search ON public.generic_ingredients USING gin (search_vector);


--
-- Name: idx_injury_poisoning_active; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_injury_poisoning_active ON public.icd10_injury_poisoning USING btree (active) WHERE (active = true);


--
-- Name: idx_injury_poisoning_code; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_injury_poisoning_code ON public.icd10_injury_poisoning USING btree (code);


--
-- Name: idx_injury_poisoning_term_gin; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_injury_poisoning_term_gin ON public.icd10_injury_poisoning USING gin (to_tsvector('english'::regconfig, term));


--
-- Name: idx_interaction_drug_a; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_interaction_drug_a ON public.drug_interactions USING btree (drug_a_id);


--
-- Name: idx_interaction_drug_b; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_interaction_drug_b ON public.drug_interactions USING btree (drug_b_id);


--
-- Name: idx_mental_behavioral_active; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_mental_behavioral_active ON public.icd10_mental_behavioral USING btree (active) WHERE (active = true);


--
-- Name: idx_mental_behavioral_code; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_mental_behavioral_code ON public.icd10_mental_behavioral USING btree (code);


--
-- Name: idx_mental_behavioral_term_gin; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_mental_behavioral_term_gin ON public.icd10_mental_behavioral USING gin (to_tsvector('english'::regconfig, term));


--
-- Name: idx_musculoskeletal_active; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_musculoskeletal_active ON public.icd10_musculoskeletal USING btree (active) WHERE (active = true);


--
-- Name: idx_musculoskeletal_code; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_musculoskeletal_code ON public.icd10_musculoskeletal USING btree (code);


--
-- Name: idx_musculoskeletal_term_gin; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_musculoskeletal_term_gin ON public.icd10_musculoskeletal USING gin (to_tsvector('english'::regconfig, term));


--
-- Name: idx_mv_chapter_stats_chapter; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE UNIQUE INDEX idx_mv_chapter_stats_chapter ON public.mv_chapter_stats USING btree (chapter);


--
-- Name: idx_mv_popular_searches_count; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_mv_popular_searches_count ON public.mv_popular_searches USING btree (search_count DESC);


--
-- Name: idx_neoplasms_blood_active; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_neoplasms_blood_active ON public.icd10_neoplasms_blood USING btree (active) WHERE (active = true);


--
-- Name: idx_neoplasms_blood_code; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_neoplasms_blood_code ON public.icd10_neoplasms_blood USING btree (code);


--
-- Name: idx_neoplasms_blood_term_gin; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_neoplasms_blood_term_gin ON public.icd10_neoplasms_blood USING gin (to_tsvector('english'::regconfig, term));


--
-- Name: idx_nervous_system_active; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_nervous_system_active ON public.icd10_nervous_system USING btree (active) WHERE (active = true);


--
-- Name: idx_nervous_system_code; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_nervous_system_code ON public.icd10_nervous_system USING btree (code);


--
-- Name: idx_nervous_system_term_gin; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_nervous_system_term_gin ON public.icd10_nervous_system USING gin (to_tsvector('english'::regconfig, term));


--
-- Name: idx_outbreak_trends_unique; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE UNIQUE INDEX idx_outbreak_trends_unique ON public.outbreak_trends USING btree (location, icd10_code, week);


--
-- Name: idx_perinatal_active; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_perinatal_active ON public.icd10_perinatal USING btree (active) WHERE (active = true);


--
-- Name: idx_perinatal_code; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_perinatal_code ON public.icd10_perinatal USING btree (code);


--
-- Name: idx_perinatal_term_gin; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_perinatal_term_gin ON public.icd10_perinatal USING gin (to_tsvector('english'::regconfig, term));


--
-- Name: idx_pregnancy_childbirth_active; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_pregnancy_childbirth_active ON public.icd10_pregnancy_childbirth USING btree (active) WHERE (active = true);


--
-- Name: idx_pregnancy_childbirth_code; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_pregnancy_childbirth_code ON public.icd10_pregnancy_childbirth USING btree (code);


--
-- Name: idx_pregnancy_childbirth_term_gin; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_pregnancy_childbirth_term_gin ON public.icd10_pregnancy_childbirth USING gin (to_tsvector('english'::regconfig, term));


--
-- Name: idx_prescription_drugs_generic; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_prescription_drugs_generic ON public.prescription_drugs USING gin (generic_name public.gin_trgm_ops);


--
-- Name: idx_prescription_drugs_prescription; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_prescription_drugs_prescription ON public.prescription_drugs USING btree (prescription_id);


--
-- Name: idx_prescription_drugs_snomed; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_prescription_drugs_snomed ON public.prescription_drugs USING btree (snomed_id);


--
-- Name: idx_prescriptions_date; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_prescriptions_date ON public.prescriptions USING btree (prescribed_date);


--
-- Name: idx_prescriptions_hospital; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_prescriptions_hospital ON public.prescriptions USING btree (hospital_id);


--
-- Name: idx_prescriptions_icd10; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_prescriptions_icd10 ON public.prescriptions USING btree (icd10_code);


--
-- Name: idx_prescriptions_location; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_prescriptions_location ON public.prescriptions USING btree (location);


--
-- Name: idx_respiratory_active; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_respiratory_active ON public.icd10_respiratory USING btree (active) WHERE (active = true);


--
-- Name: idx_respiratory_code; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_respiratory_code ON public.icd10_respiratory USING btree (code);


--
-- Name: idx_respiratory_term_gin; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_respiratory_term_gin ON public.icd10_respiratory USING gin (to_tsvector('english'::regconfig, term));


--
-- Name: idx_rxnorm_cui; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_rxnorm_cui ON public.generic_ingredients USING btree (rxnorm_cui);


--
-- Name: idx_search_logs_2026_01_created_at; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_search_logs_2026_01_created_at ON public.search_logs_2026_01 USING btree (created_at);


--
-- Name: idx_search_logs_2026_01_user_query; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_search_logs_2026_01_user_query ON public.search_logs_2026_01 USING btree (user_id, query);


--
-- Name: idx_search_logs_2026_02_created_at; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_search_logs_2026_02_created_at ON public.search_logs_2026_02 USING btree (created_at);


--
-- Name: idx_search_logs_2026_02_user_query; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_search_logs_2026_02_user_query ON public.search_logs_2026_02 USING btree (user_id, query);


--
-- Name: idx_search_logs_2026_03_created_at; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_search_logs_2026_03_created_at ON public.search_logs_2026_03 USING btree (created_at);


--
-- Name: idx_search_logs_2026_03_user_query; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_search_logs_2026_03_user_query ON public.search_logs_2026_03 USING btree (user_id, query);


--
-- Name: idx_search_logs_2026_04_created_at; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_search_logs_2026_04_created_at ON public.search_logs_2026_04 USING btree (created_at);


--
-- Name: idx_search_logs_2026_04_user_query; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_search_logs_2026_04_user_query ON public.search_logs_2026_04 USING btree (user_id, query);


--
-- Name: idx_search_logs_2026_05_created_at; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_search_logs_2026_05_created_at ON public.search_logs_2026_05 USING btree (created_at);


--
-- Name: idx_search_logs_2026_05_user_query; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_search_logs_2026_05_user_query ON public.search_logs_2026_05 USING btree (user_id, query);


--
-- Name: idx_search_logs_2026_06_created_at; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_search_logs_2026_06_created_at ON public.search_logs_2026_06 USING btree (created_at);


--
-- Name: idx_search_logs_2026_06_user_query; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_search_logs_2026_06_user_query ON public.search_logs_2026_06 USING btree (user_id, query);


--
-- Name: idx_search_logs_2026_07_created_at; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_search_logs_2026_07_created_at ON public.search_logs_2026_07 USING btree (created_at);


--
-- Name: idx_search_logs_2026_07_user_query; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_search_logs_2026_07_user_query ON public.search_logs_2026_07 USING btree (user_id, query);


--
-- Name: idx_search_logs_api_key; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_search_logs_api_key ON public.search_logs USING btree (api_key);


--
-- Name: idx_search_logs_created_at; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_search_logs_created_at ON public.search_logs USING btree (created_at);


--
-- Name: idx_search_logs_query; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_search_logs_query ON public.search_logs USING btree (query);


--
-- Name: idx_skin_subcutaneous_active; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_skin_subcutaneous_active ON public.icd10_skin_subcutaneous USING btree (active) WHERE (active = true);


--
-- Name: idx_skin_subcutaneous_code; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_skin_subcutaneous_code ON public.icd10_skin_subcutaneous USING btree (code);


--
-- Name: idx_skin_subcutaneous_term_gin; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_skin_subcutaneous_term_gin ON public.icd10_skin_subcutaneous USING gin (to_tsvector('english'::regconfig, term));


--
-- Name: idx_snomed_brand_active; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_snomed_brand_active ON public.snomed_brands USING btree (active) WHERE (active = true);


--
-- Name: idx_snomed_brand_generic; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_snomed_brand_generic ON public.snomed_brands USING btree (generic_id);


--
-- Name: idx_snomed_brand_generic_route; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_snomed_brand_generic_route ON public.snomed_brands USING btree (generic_id, route_of_administration) WHERE (active = true);


--
-- Name: idx_snomed_brand_name; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_snomed_brand_name ON public.snomed_brands USING gin (brand_name public.gin_trgm_ops);


--
-- Name: idx_snomed_brand_product; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_snomed_brand_product ON public.snomed_brands USING btree (product_id);


--
-- Name: idx_snomed_brand_route; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_snomed_brand_route ON public.snomed_brands USING btree (route_of_administration);


--
-- Name: idx_snomed_brand_search; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_snomed_brand_search ON public.snomed_brands USING gin (search_vector);


--
-- Name: idx_snomed_brand_supplier; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_snomed_brand_supplier ON public.snomed_brands USING btree (supplier_id);


--
-- Name: idx_snomed_cas; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_snomed_cas ON public.snomed_substances USING btree (cas_number) WHERE (cas_number IS NOT NULL);


--
-- Name: idx_snomed_complete_brand_id; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE UNIQUE INDEX idx_snomed_complete_brand_id ON public.snomed_drugs_complete USING btree (brand_snomed_id);


--
-- Name: idx_snomed_complete_brand_name; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_snomed_complete_brand_name ON public.snomed_drugs_complete USING gin (brand_name public.gin_trgm_ops);


--
-- Name: idx_snomed_complete_generic_name; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_snomed_complete_generic_name ON public.snomed_drugs_complete USING gin (generic_name public.gin_trgm_ops);


--
-- Name: idx_snomed_complete_supplier; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_snomed_complete_supplier ON public.snomed_drugs_complete USING gin (supplier_name public.gin_trgm_ops);


--
-- Name: idx_snomed_etl_log_created; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_snomed_etl_log_created ON public.snomed_etl_log USING btree (created_at DESC);


--
-- Name: idx_snomed_form_name; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_snomed_form_name ON public.snomed_drug_forms USING btree (form_name);


--
-- Name: idx_snomed_generic_indication; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_snomed_generic_indication ON public.snomed_generics USING gin (indication public.gin_trgm_ops) WHERE (indication IS NOT NULL);


--
-- Name: idx_snomed_generic_name; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_snomed_generic_name ON public.snomed_generics USING gin (generic_name public.gin_trgm_ops);


--
-- Name: idx_snomed_generic_search; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_snomed_generic_search ON public.snomed_generics USING gin (search_vector);


--
-- Name: idx_snomed_product_name; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_snomed_product_name ON public.snomed_products USING gin (product_name public.gin_trgm_ops);


--
-- Name: idx_snomed_product_search; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_snomed_product_search ON public.snomed_products USING gin (search_vector);


--
-- Name: idx_snomed_route_name; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_snomed_route_name ON public.snomed_routes USING btree (route_name);


--
-- Name: idx_snomed_substance_name; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_snomed_substance_name ON public.snomed_substances USING gin (substance_name public.gin_trgm_ops);


--
-- Name: idx_snomed_supplier_active; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_snomed_supplier_active ON public.snomed_suppliers USING btree (active) WHERE (active = true);


--
-- Name: idx_snomed_supplier_name; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_snomed_supplier_name ON public.snomed_suppliers USING gin (supplier_name public.gin_trgm_ops);


--
-- Name: idx_snomed_supplier_search; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_snomed_supplier_search ON public.snomed_suppliers USING gin (search_vector);


--
-- Name: idx_snomed_unii; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_snomed_unii ON public.snomed_substances USING btree (unii) WHERE (unii IS NOT NULL);


--
-- Name: idx_symptoms_signs_active; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_symptoms_signs_active ON public.icd10_symptoms_signs USING btree (active) WHERE (active = true);


--
-- Name: idx_symptoms_signs_code; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_symptoms_signs_code ON public.icd10_symptoms_signs USING btree (code);


--
-- Name: idx_symptoms_signs_term_gin; Type: INDEX; Schema: public; Owner: samirkolhe
--

CREATE INDEX idx_symptoms_signs_term_gin ON public.icd10_symptoms_signs USING gin (to_tsvector('english'::regconfig, term));


--
-- Name: abhbp_procedures abhbp_search_vector_update; Type: TRIGGER; Schema: public; Owner: samirkolhe
--

CREATE TRIGGER abhbp_search_vector_update BEFORE INSERT OR UPDATE ON public.abhbp_procedures FOR EACH ROW EXECUTE FUNCTION public.update_abhbp_search_vector();


--
-- Name: indian_brand_drugs brand_search_vector_update; Type: TRIGGER; Schema: public; Owner: samirkolhe
--

CREATE TRIGGER brand_search_vector_update BEFORE INSERT OR UPDATE ON public.indian_brand_drugs FOR EACH ROW EXECUTE FUNCTION public.update_drug_search_vector();


--
-- Name: generic_ingredients generic_search_vector_update; Type: TRIGGER; Schema: public; Owner: samirkolhe
--

CREATE TRIGGER generic_search_vector_update BEFORE INSERT OR UPDATE ON public.generic_ingredients FOR EACH ROW EXECUTE FUNCTION public.update_generic_search_vector();


--
-- Name: snomed_brands snomed_brand_search_update; Type: TRIGGER; Schema: public; Owner: samirkolhe
--

CREATE TRIGGER snomed_brand_search_update BEFORE INSERT OR UPDATE ON public.snomed_brands FOR EACH ROW EXECUTE FUNCTION public.update_snomed_brand_search();


--
-- Name: snomed_generics snomed_generic_search_update; Type: TRIGGER; Schema: public; Owner: samirkolhe
--

CREATE TRIGGER snomed_generic_search_update BEFORE INSERT OR UPDATE ON public.snomed_generics FOR EACH ROW EXECUTE FUNCTION public.update_snomed_generic_search();


--
-- Name: snomed_products snomed_product_search_update; Type: TRIGGER; Schema: public; Owner: samirkolhe
--

CREATE TRIGGER snomed_product_search_update BEFORE INSERT OR UPDATE ON public.snomed_products FOR EACH ROW EXECUTE FUNCTION public.update_snomed_product_search();


--
-- Name: snomed_suppliers snomed_supplier_search_update; Type: TRIGGER; Schema: public; Owner: samirkolhe
--

CREATE TRIGGER snomed_supplier_search_update BEFORE INSERT OR UPDATE ON public.snomed_suppliers FOR EACH ROW EXECUTE FUNCTION public.update_snomed_supplier_search();


--
-- Name: drug_contraindications drug_contraindications_drug_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.drug_contraindications
    ADD CONSTRAINT drug_contraindications_drug_id_fkey FOREIGN KEY (drug_id) REFERENCES public.generic_ingredients(ingredient_id);


--
-- Name: drug_interactions drug_interactions_drug_a_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.drug_interactions
    ADD CONSTRAINT drug_interactions_drug_a_id_fkey FOREIGN KEY (drug_a_id) REFERENCES public.generic_ingredients(ingredient_id);


--
-- Name: drug_interactions drug_interactions_drug_b_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.drug_interactions
    ADD CONSTRAINT drug_interactions_drug_b_id_fkey FOREIGN KEY (drug_b_id) REFERENCES public.generic_ingredients(ingredient_id);


--
-- Name: indian_brand_drugs indian_brand_drugs_ingredient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.indian_brand_drugs
    ADD CONSTRAINT indian_brand_drugs_ingredient_id_fkey FOREIGN KEY (ingredient_id) REFERENCES public.generic_ingredients(ingredient_id);


--
-- Name: prescription_drugs prescription_drugs_prescription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.prescription_drugs
    ADD CONSTRAINT prescription_drugs_prescription_id_fkey FOREIGN KEY (prescription_id) REFERENCES public.prescriptions(prescription_id);


--
-- Name: snomed_brands snomed_brands_generic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: samirkolhe
--

ALTER TABLE ONLY public.snomed_brands
    ADD CONSTRAINT snomed_brands_generic_id_fkey FOREIGN KEY (generic_id) REFERENCES public.snomed_generics(snomed_id);


--
-- PostgreSQL database dump complete
--

